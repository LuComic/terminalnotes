# terminalnotes
A simple, yet fast and efficient note taking app in your terminal!

## Installation

To install, run:

```bash
pip3 install termnotes